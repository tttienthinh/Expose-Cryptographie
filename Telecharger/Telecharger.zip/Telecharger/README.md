# Exposé d'IPT Cryptographie du Mercredi 5 Janvier 2022
J'ai mis dans ce dossier tous les fichiers que je présenterai à l'oral. \
Si le jour de la présentation vous n'avez pas accès à un ordinateur, [le code est aussi disponible ici](https://colab.research.google.com/drive/1BFb5CMJwijUhsHAyECveqfO36PPvT2_O?usp=sharing)
\
\
Pour avoir tout le dossier au format zip, vous pouvez cliquer sur le lien ci-dessous : \
https://github.com/tttienthinh/Expose-Cryptographie/raw/main/Telecharger/Telecharger.zip
\
\
TRAN-THUONG Tien-Thinh MP*